module.exports =
{
    "URI": "mongodb+srv://Josh_14:XyRBwBEnLI5uFwB4@cluster0.58ojfky.mongodb.net/CarStore"
}